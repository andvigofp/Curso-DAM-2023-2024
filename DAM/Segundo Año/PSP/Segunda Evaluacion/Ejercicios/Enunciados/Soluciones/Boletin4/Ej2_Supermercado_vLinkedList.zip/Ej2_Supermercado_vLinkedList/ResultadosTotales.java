package Ej2_Supermercado_vLinkedList;

public class ResultadosTotales {
    public static int ganancias;
}
