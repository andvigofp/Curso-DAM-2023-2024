package Ej3_Parking;

import java.util.Scanner;

public class Parking {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca numero de coches");
        int C = sc.nextInt();
        System.out.println("Introduzca numero de plazas");
        int N = sc.nextInt();

        //Inicializar el parking
        Barrera barrera = new Barrera(N);
        Coche coches[] = new Coche[C];
        for (int i = 0; i < C; i++) {
            coches[i] = new Coche(i + 1, barrera);
            coches[i].start();
        }
        try {
            for (int i = 0; i < C; i++) {
                coches[i].join();
            }
        } catch (InterruptedException ex) {
            System.out.println("Hilo principal interrumpido.");
        }
    }
}