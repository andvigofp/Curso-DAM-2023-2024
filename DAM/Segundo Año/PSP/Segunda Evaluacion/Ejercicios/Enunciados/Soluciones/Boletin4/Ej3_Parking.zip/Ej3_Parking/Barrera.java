package Ej3_Parking;

public class Barrera {
    private int plazas[];
    private int n_plazas;
    private int libres;

    Barrera(int N) {
        n_plazas = N;
        plazas = new int[N];
        // Inicializo parking
        for (int i = 0; i < n_plazas; i++) {
            plazas[i] = 0;
        }
        libres = n_plazas;
    }

    synchronized public int entraCoche(int coche) throws InterruptedException {
        int plaza = 0;
        imprimirEstadoParking();
        // El coche espera a que haya plazas para entrar
        while (libres == 0) {
            System.out.println("Coche " + coche + " esperando");
            wait();
        }

        // Cuando hay hueco en el parking
        // busco la primera plaza disponible en el parking
        while (plazas[plaza] != 0) {
            plaza++;
        }

        // Asigno la plaza al coche
        plazas[plaza] = coche;
        libres--;
        return plaza;
    }

    synchronized public void saleCoche(int plaza) {
        plazas[plaza] = 0;
        libres++;
        notify();
    }

    public void imprimirEstadoParking() {
        System.out.print("Parking: ");
        for (int i = 0; i < n_plazas; i++) {
            System.out.print("[" + plazas[i] + "] ");
        }
        System.out.println("");
    }
}