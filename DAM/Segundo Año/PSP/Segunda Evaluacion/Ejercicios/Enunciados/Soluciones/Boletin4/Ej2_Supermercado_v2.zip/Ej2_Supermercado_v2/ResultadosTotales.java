package Ej2_Supermercado_v2;

public class ResultadosTotales {
    public static int ganancias;
}
