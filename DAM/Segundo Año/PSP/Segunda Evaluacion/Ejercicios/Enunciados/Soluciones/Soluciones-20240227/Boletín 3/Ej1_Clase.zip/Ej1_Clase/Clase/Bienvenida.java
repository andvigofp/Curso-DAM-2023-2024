package Ej1_Clase.Clase;

/**
 * Se trata de simular el comienzo de una clase.
 *
 * Los alumnos llegarán y esperarán hasta que llegue el profesor y salude para que comience la clase.
 *
 * Los alumnos y el profesor compartirán un objeto de la clase Bienvenida, con dos métodos sincronizados:
 *
 * * Uno donde los alumnos llegan y saludan al profesor (se quedan esperando mientras el profesor no llegue)
 *
 * * Otro donde el profesor llega e indica que la clase puede comenzar, notificándoselo a los alumnos.
 *
 */


public class Bienvenida {
    boolean clase_comenzada;

    public Bienvenida() {
        this.clase_comenzada = false;
    }

    public synchronized void entrarySaludar(int num) {
        try {
            if (!clase_comenzada) {
                wait();
            }
            System.out.println("Alumno " + num + ": Buenos días profesor");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public synchronized void llegadaProfesor(String nombre) {
        System.out.println("Buenos días a todos. Soy " + nombre);
        this.clase_comenzada = true;
        notifyAll();
    }
}
