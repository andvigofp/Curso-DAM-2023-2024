package Ej1_Clase.Clase;

public class Alumno extends Thread {
    Bienvenida saludo;
    int numAlumno;

    public Alumno (Bienvenida bienvenida, int numAlumno) {
        this.saludo = bienvenida;
        this.numAlumno = numAlumno;
    }

    public void run() {
        System.out.println("Alumno " + numAlumno + " llegó");
        try {
            Thread.sleep(1000);
            saludo.entrarySaludar(numAlumno);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
