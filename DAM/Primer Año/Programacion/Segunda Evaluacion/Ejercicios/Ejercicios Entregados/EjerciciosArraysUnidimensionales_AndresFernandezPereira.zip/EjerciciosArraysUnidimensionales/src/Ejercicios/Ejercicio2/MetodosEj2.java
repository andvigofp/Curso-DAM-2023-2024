package Ejercicios.Ejercicio2;

public class MetodosEj2 {


    //Método para mostrar el resultado del array
    public static void resultadoCaracter(char caracter[]) {
        for (char simbolo : caracter) {
            System.out.print("\t" + simbolo);
        }

    }
}

