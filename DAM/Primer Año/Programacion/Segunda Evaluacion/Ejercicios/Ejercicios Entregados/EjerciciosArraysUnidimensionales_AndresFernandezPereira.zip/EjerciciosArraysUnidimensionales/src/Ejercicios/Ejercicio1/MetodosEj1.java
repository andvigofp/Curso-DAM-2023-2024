package Ejercicios.Ejercicio1;

public class MetodosEj1 {

    //Método para mostrar el resultado del array
    public static void resultadoNum(int nummero[]) {
        for (int num : nummero) {
            System.out.print("\t\t"+ num);

        }
    }

}

