public class EjemploAutomovilEnum {

    public static void main(String[] args) {

        Automovil subaru = new Automovil("subaru","Impreza_turbo_diesel");


        Automovil.setCapacidadDepositoEstatico(45);
        //subaru.setFabricante("subaru");
        subaru.setColor(Color.GRIS);
        subaru.setCilindrada(3.3);
        //subaru.setModelo("Impreza_ turbo_diesel");
        subaru.setTipo(TipoAutomovil.HATCHBACK);
        
        Automovil mazda=new Automovil("mazda","X3 commondRail");

        mazda.setTipo(TipoAutomovil.PICKUP);

        System.out.println("mazda.fabricante = "+ mazda.getFabricante());

        Automovil nissan = new Automovil("Nissan", "Navara",Color.GRIS,3.5,50);

        nissan.setTipo(TipoAutomovil.PICKUP);
        
        Automovil nissan2 = new Automovil("nissan","navara",Color.AZUL,5.0,50);

        nissan2.setTipo(TipoAutomovil.PICKUP);

        Automovil toyota = new Automovil("toyota","celica",Color.GRIS,3.6);

        toyota.setTipo(TipoAutomovil.CONVERTIBLE);


        System.out.println("\nnissan2.detalle() = " + nissan2.detalle());
        System.out.println("\nnissan.detalle() = " + nissan.detalle());
        System.out.println("mazda = " + mazda.detalle());
        System.out.println("subaru = " + subaru.detalle() );

        TipoAutomovil tipoSubaru = subaru.getTipo();
        System.out.println("Tipo subaru = " +tipoSubaru.getNombre());
        System.out.println("Tipo descripción subaru = " +tipoSubaru.getDescripcion());

        System.out.println("\nEstos son los datos de Toyota : " + toyota.detalle());


 
    }


}
