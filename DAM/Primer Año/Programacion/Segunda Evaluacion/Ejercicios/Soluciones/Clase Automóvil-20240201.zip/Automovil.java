public class Automovil {
    private int id = 0;
    private String fabricante;
    private String modelo;
    private Color color = Color.GRIS;
    private double cilindrada;
    private int capacidadDeposito = 40;
    private  TipoAutomovil tipo;
    private static Color colorPatente = Color.NARANJA;

    private static int capacidadDepositoEstatico = 30;

    private static int ultimoId;
    public static final Integer VELOCIDAD_MAXIMA_CARRETERA = 120;
    public static final int VELOCIDAD_MAXIMA_CIUDAD = 50;
    public static final String COLOR_ROJO="Rojo";
    public static final String COLOR_AMARILLO="Amarillo";
    public static final String COLOR_AZUL="Azul";
    public static final String COLOR_BLANCO="Blanco";
    public static final String COLOR_GRIS="Gris Oscuro";
    public Automovil(){

        this.id= ++ultimoId;


    }
    public Automovil(String fabricante, String modelo){

        this();
        this.fabricante=fabricante;
        this.modelo=modelo;


    }



    public  Automovil( String fabricante, String modelo, Color color ){

        this(fabricante,modelo);
        this.color=color;
    }

    public Automovil (String fabricante,String modelo, Color color, double cilindrada){

        this(fabricante,modelo,color);
        this.cilindrada=cilindrada;
    }

    public Automovil (String fabricante, String modelo, Color color,double cilindrada,int deposito){

        this(fabricante,modelo,color,cilindrada);
        this.capacidadDeposito=deposito;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public double getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(double cilindrada) {
        this.cilindrada = cilindrada;
    }

    public int getCapacidadDeposito() {
        return capacidadDeposito;
    }

    public void setCapacidadDeposito(int capacidadDeposito) {
        this.capacidadDeposito = capacidadDeposito;
    }

    public static Color getColorPatente(){

        return colorPatente;
    }

    public static void setColorPatente (Color colorPatente){

        Automovil.colorPatente=colorPatente;
    }

    public TipoAutomovil getTipo() {
        return tipo;
    }

    public void setTipo(TipoAutomovil tipo) {
        this.tipo = tipo;
    }

    public static int getCapacidadDepositoEstatico() {
        return capacidadDepositoEstatico;
    }

    public static void setCapacidadDepositoEstatico(int capacidadDepositoEstatico) {
        Automovil.capacidadDepositoEstatico = capacidadDepositoEstatico;
    }

    public  String detalle() {

         return  "\nauto.Id = " + this.id +
                 "\nauto.fabricante = " + this.fabricante +
                 "\nauto.color = " + color.getColor() +
                 "\nauto.modelo = " + this.modelo +
                 "\nauto.tipo  = "+this.getTipo().getDescripcion()+
                 "\nauto.Número de puertas   = "+this.getTipo().getNumeroPuerta()+
                 "\nauto.colorPalente = " + Automovil.colorPatente.getColor()+
                 "\nauto.cilindrada = " + this.cilindrada;


    }

    public String acelerar(int rpm) {

        return "el auto " + fabricante + " acelerando a " + rpm + " r.p.m.";

    }

    public String frenar() {

        return fabricante + " " + this.modelo + " frenando!!!";


    }

    public String acelerarFrenar(int rpm) {

        String acelerar = acelerar(rpm);
        String frenar = frenar();
        return acelerar + "\n" + frenar;
    }

    public float calucularConsumo(int km, float porcentajeGasolina) {

        return km / (capacidadDeposito * porcentajeGasolina);

    }

    public float calucularConsumo(int km, int porcentajeGasolina) {

        return km / (capacidadDeposito * (porcentajeGasolina / 100f));
    }
    public static float calucularConsumoEstatico(int km, int porcentajeGasolina) {

        return km / (Automovil.capacidadDepositoEstatico * (porcentajeGasolina / 100f));
    }
}