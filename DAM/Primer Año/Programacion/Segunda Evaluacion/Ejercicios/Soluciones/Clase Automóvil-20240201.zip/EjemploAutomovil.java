public class EjemploAutomovil {

    public static void main(String[] args) {

        Automovil subaru = new Automovil("subaru","Impreza_turbo_diesel");

        //subaru.setFabricante("subaru");
        subaru.setColor(Color.ROJO);
        subaru.setCilindrada(3.3);
        //subaru.setModelo("Impreza_turbo_diesel");
        
        Automovil mazda=new Automovil("mazda","X3 commondRail");
        
        //mazda.setFabricante("mazda");
        mazda.setColor(Color.BLANCO);
        mazda.setCilindrada(4.5);
        //mazda.setModelo("X3 commonRail");


        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*- Características del subaru");
        System.out.println("subaru.fabricante = " + subaru.getFabricante());
        System.out.println("subaru.color = " + subaru.getColor());
        System.out.println("subaru.modelo = " + subaru.getModelo());
        System.out.println("subaru.cilindrada = " + subaru.getCilindrada());

        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*- Características del mazda");

        System.out.println("mazda.fabricante = " + mazda.getFabricante());
        System.out.println("mazda.color = " + mazda.getColor());
        System.out.println("mazda.modelo = " + mazda.getModelo());
        System.out.println("mazda.cilindrada = " + mazda.getCilindrada());
        /*mazda.detalle();
        subaru.detalle();
        System.out.println("subaru = " + subaru.acelerar(3500));

        System.out.println("mazda. = " + mazda.acelerarFrenar(4000));
        System.out.println("kilómetros por litro:" + mazda.calucularConsumo(300,0.6f));
        System.out.println("kilómetros por litro:"+  mazda.calucularConsumo(300,60));*/
    }


}
