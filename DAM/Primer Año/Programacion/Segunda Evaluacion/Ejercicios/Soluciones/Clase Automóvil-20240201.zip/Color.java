public enum Color {

    ROJO("Rojo"),
    AMARILLO("Amarillo"),
    AZUL("Acul"),
    BLANCO("Blanco"),
    NARANJA("Naranja"),
    AMARILLO_LIMÓN("Amarillo limón"),
    GRIS("Gris Oscuro");
private final String color; // es final no se puede modificar

    Color(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

}
